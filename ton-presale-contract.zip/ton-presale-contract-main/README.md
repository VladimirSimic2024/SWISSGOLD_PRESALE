@author @logicbolt
@desc It's just presale on testnet.
@support  @joeaska84 gmail.


now developing contract